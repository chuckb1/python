print("Hello World")


name = "Chuck"
print("Hello", name)
print("Hello " + str(name))



name = 7
print("Hello", name)
print("Hello " + str(name))



fave_food1 = "sushi"
fave_food2 = "pizza"
print("I love to eat", fave_food1, "and", fave_food2,".")
print("I love to eat " + str(fave_food1 + " and " + str(fave_food2) + "."))

